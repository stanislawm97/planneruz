create unique index SUBJECTS_ID_UINDEX
    on "Subjects" (ID);

