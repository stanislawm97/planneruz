create unique index TEACHERS_ID_UINDEX
    on "Teachers" (ID);

